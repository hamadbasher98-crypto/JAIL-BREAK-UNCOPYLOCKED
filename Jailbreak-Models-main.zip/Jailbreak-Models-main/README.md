# **Jailbreak Models** <br> [![DSC](https://img.shields.io/badge/.gg/a4FeEk5R3E-2c3376?logo=discord)](https://discord.gg/a4FeEk5R3E) [![YT](https://img.shields.io/badge/@jbuncopylocked-fb0101?logo=youtube)](https://youtube.com/@jbuncopylocked) [![X](https://img.shields.io/badge/@jbuncopylocked-000000?logo=x)](https://x.com/jbuncopylocked) [![RBLX](https://img.shields.io/badge/@BadimoForgottenDev-3156ff?logo=roblox)](https://www.roblox.com/users/4327200522/profile)
- Some models from Jailbreak that I have saved over time!
- This does **NOT** contain every model from the game.

## **Contents**
- This repository's contents are organized by year for your comfort.

<details>
<summary><h3>2024</h3></summary>

| Model | Save Date |
| :- | :-: |
| [`CEO`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2024/CEO.rbxm) | `Apr-13-2024` |

</details>

<details>
<summary><h3>2025</h3></summary>

| Model | Save Date |
| :- | :-: |
| [`CEO`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2025/CEO.rbxm) | `Nov-24-2025` |

</details>

<details>
<summary><h3>2026</h3></summary>

| Model | Save Date |
| :- | :-: |
| [`Upper Management`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Upper%20Management.rbxl) <br> [`Basement`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Basement.rbxl) <br> [`Corridor`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Corridor.rbxl) <br> [`Classic`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Classic.rbxl) <br> [`Underwater`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Underwater.rbxl) <br> [`The Mint`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/The%20Mint.rbxl) <br> [`Presidential`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Presidential.rbxl) | `Jan-22-2026` |
|||
| [`Basement`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Basement%20(Updated).rbxl) <br> [`Underwater`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Underwater%20(Updated).rbxl) <br> [`Deductions`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Deductions.rbxl) <br> [`Presidential`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Presidential%20(Updated).rbxm) | `Jan-25-2026` |
|||
| [`AdminNuke`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/AdminNuke.rbxm) | `Jan-28-2026` |
|||
| [`CrimeKey`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/CrimeKey.rbxm) | `Jan-31-2026` |
|||
| [`Successor`](https://github.com/jbuncopylocked/Jailbreak-Models/raw/main/2026/Successor.rbxm) | `Feb-07-2026` |

</details>

---
> <h6><em> Full credit goes to Badimo, the creators of <a href="https://jb.badimo.org">Jailbreak</a>, and the orginal artists.</em></h6>